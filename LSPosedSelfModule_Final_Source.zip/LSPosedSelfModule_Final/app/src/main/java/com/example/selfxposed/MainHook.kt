package com.example.selfxposed

import android.app.Activity
import android.app.Instrumentation
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.widget.PopupWindow
import android.widget.TextView
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val pkg = lpparam.packageName ?: return
        if (pkg == MODULE_PACKAGE || pkg.startsWith("android.")) return
        try {
            XposedHelpers.findAndHookMethod(
                Instrumentation::class.java, "callActivityOnResume", Activity::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val activity = param.args.firstOrNull() as? Activity ?: return
                        if (activity.packageName != pkg || activity.isFinishing || activity.isDestroyed) return
                        val cfg = try {
                            val result = activity.contentResolver.call(CONFIG_URI, "get_config", pkg, null)
                            JSONObject(result?.getString("config") ?: "{}")
                        } catch (t: Throwable) {
                            writeLog(activity, pkg, "读取配置失败：${t.javaClass.simpleName}")
                            return
                        }
                        if (!cfg.optBoolean("enabled", false) || !cfg.optBoolean("popupEnabled", true)) return

                        val now = System.currentTimeMillis()
                        val existing = popupStates[pkg]
                        if (existing != null && now < existing.endAt) {
                            // Activity 切换时将弹窗重新挂到新页面，但不重置总计时。
                            activity.window.decorView.post { renderPopup(activity, pkg, cfg, existing) }
                            return
                        }
                        val showMs = cfg.optLong("showMs", 5000L).coerceIn(500L, 60000L)
                        val fadeMs = cfg.optLong("fadeMs", 1000L).coerceIn(0L, 5000L)
                        val state = PopupState(now, now + showMs + fadeMs, showMs, fadeMs)
                        popupStates[pkg] = state
                        writeLog(activity, pkg, "弹窗触发：显示 ${showMs}ms，淡出 ${fadeMs}ms")
                        activity.window.decorView.post { renderPopup(activity, pkg, cfg, state) }
                        mainHandler.postDelayed({
                            val current = popupStates[pkg]
                            if (current === state) {
                                try { current.popup?.dismiss() } catch (_: Throwable) {}
                                popupStates.remove(pkg, state)
                                writeLog(activity, pkg, "弹窗已结束")
                            }
                        }, showMs + fadeMs)
                    }
                }
            )
        } catch (_: Throwable) { }
    }

    private fun renderPopup(activity: Activity, pkg: String, cfg: JSONObject, state: PopupState) {
        if (activity.isFinishing || activity.isDestroyed || System.currentTimeMillis() >= state.endAt) return
        val decor = activity.window.decorView
        if (!decor.isAttachedToWindow) return
        try { state.popup?.dismiss() } catch (_: Throwable) {}
        val density = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * density + 0.5f).toInt()
        val text = TextView(activity).apply {
            this.text = cfg.optString("popupText", "你好")
            textSize = 16f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(12), dp(22), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.rgb(225, 225, 225))
            }
            elevation = dp(8).toFloat()
        }
        val popup = PopupWindow(text, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, false)
        popup.isClippingEnabled = true
        try {
            popup.showAtLocation(decor, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, 0, dp(72))
            state.popup = popup
            val elapsed = System.currentTimeMillis() - state.startedAt
            if (elapsed >= state.showMs && state.fadeMs > 0) {
                val fadeElapsed = (elapsed - state.showMs).coerceAtLeast(0L)
                val remainingFade = (state.fadeMs - fadeElapsed).coerceAtLeast(1L)
                text.alpha = (1f - fadeElapsed.toFloat() / state.fadeMs.toFloat()).coerceIn(0f, 1f)
                text.startAnimation(AlphaAnimation(text.alpha, 0f).apply {
                    duration = remainingFade
                    fillAfter = true
                })
            }
        } catch (t: Throwable) {
            writeLog(activity, pkg, "弹窗显示失败：${t.javaClass.simpleName}")
        }
    }

    private fun writeLog(activity: Activity, pkg: String, message: String) {
        try {
            val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            val extras = Bundle().apply { putString("line", "$time  $message") }
            activity.contentResolver.call(CONFIG_URI, "append_log", pkg, extras)
        } catch (_: Throwable) {}
    }

    private data class PopupState(
        val startedAt: Long,
        val endAt: Long,
        val showMs: Long,
        val fadeMs: Long,
        @Volatile var popup: PopupWindow? = null
    )

    companion object {
        private const val MODULE_PACKAGE = "com.example.selfxposed"
        private val CONFIG_URI = Uri.parse("content://com.example.selfxposed.config")
        private val popupStates = ConcurrentHashMap<String, PopupState>()
        private val mainHandler = Handler(Looper.getMainLooper())
    }
}
