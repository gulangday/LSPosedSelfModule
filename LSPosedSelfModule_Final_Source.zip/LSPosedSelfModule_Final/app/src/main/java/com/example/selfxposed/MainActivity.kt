package com.example.selfxposed

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(246, 247, 251)
    private val ink = Color.rgb(30, 35, 48)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var selectedPackage = "com.kugou.android.lite"
    private var selectedName = "酷狗概念版"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildHome()
    }

    private fun buildHome() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(73, 89, 220), Color.rgb(124, 77, 210)))
        }
        header.addView(label("自用模块", 25, Color.WHITE, true))
        header.addView(label("LSPosed · 按应用独立配置", 13, Color.rgb(230, 232, 255), false))
        root.addView(header)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(22)) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        showHome()
    }

    private fun showHome() {
        content.removeAllViews()
        content.addView(sectionTitle("目标应用"))
        content.addView(label("必须先在 LSPosed 管理器中勾选对应应用的作用域，再在这里启用模块功能。", 13, Color.DKGRAY, false).apply {
            setPadding(dp(4), dp(4), dp(4), dp(12))
        })
        val apps = loadLaunchableApps()
        val known = apps.firstOrNull { it.first == "com.kugou.android.lite" }
        val rows = linkedMapOf<String, String>()
        rows["com.kugou.android.lite"] = known?.second ?: "酷狗概念版（未安装或无法读取）"
        apps.forEach { (p, n) -> if (p != packageName) rows[p] = n }
        rows.forEach { (pkg, name) ->
            val cfg = ConfigClient.config(contentResolver, pkg)
            val card = card()
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val appIcon = try { packageManager.getApplicationIcon(pkg) } catch (_: Throwable) { null }
            if (appIcon != null) row.addView(ImageView(this).apply { setImageDrawable(appIcon) },
                LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(12) })
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            details.addView(label(name, 16, ink, true))
            details.addView(label(pkg, 11, Color.GRAY, false))
            details.addView(label("版本：${getVersion(pkg)}", 11, Color.GRAY, false))
            row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            val toggle = Switch(this).apply {
                isChecked = cfg.optBoolean("enabled", false)
                setOnCheckedChangeListener { _, checked ->
                    if (checked) {
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("确认启用")
                            .setMessage("请确认已在 LSPosed 管理器中为「$name」勾选模块作用域。\n\n模块应用无法可靠读取 LSPosed 管理器当前的作用域勾选状态，因此这里会先提醒你确认。若未勾选，功能不会生效。")
                            .setNegativeButton("取消") { _, _ -> isChecked = false }
                            .setPositiveButton("我已勾选") { _, _ ->
                                cfg.put("enabled", true); ConfigClient.save(contentResolver, pkg, cfg)
                                ConfigClient.log(contentResolver, pkg, "已在模块设置中启用")
                            }.show()
                    } else {
                        cfg.put("enabled", false); ConfigClient.save(contentResolver, pkg, cfg)
                        ConfigClient.log(contentResolver, pkg, "已在模块设置中关闭")
                    }
                }
            }
            row.addView(toggle)
            card.addView(row)
            card.setOnClickListener { selectedPackage = pkg; selectedName = name; showAppSettings() }
            content.addView(card)
        }
        content.addView(sectionTitle("工具"))
        content.addView(actionCard("实时日志", "查看各目标应用的模块运行记录") { showLogsPicker() })
        content.addView(actionCard("使用说明", "作用域与模块开关需要同时启用") { showHelp() })
        content.addView(label("提示：点击任一应用卡片可配置该应用的弹窗文字、显示时间和日志。", 12, Color.GRAY, false).apply {
            setPadding(dp(4), dp(10), dp(4), dp(4))
        })
    }

    private fun showAppSettings() {
        content.removeAllViews()
        val cfg = ConfigClient.config(contentResolver, selectedPackage)
        content.addView(backRow("‹  返回目标应用") { showHome() })
        content.addView(sectionTitle(selectedName))
        content.addView(label(selectedPackage, 12, Color.GRAY, false))
        content.addView(actionCard("功能：底部提示弹窗", "白色背景、黑色文字；显示 5 秒后淡出 1 秒") {})
        val popupSwitch = Switch(this).apply {
            text = "启用提示弹窗"
            isChecked = cfg.optBoolean("popupEnabled", true)
        }
        content.addView(card().apply { addView(popupSwitch) })
        val edit = EditText(this).apply {
            hint = "弹窗文字"
            setText(cfg.optString("popupText", "你好"))
            textSize = 16f
            setSingleLine(false)
            minLines = 2
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.WHITE, dp(12))
        }
        content.addView(edit, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        val showTime = EditText(this).apply {
            hint = "显示时间（毫秒），默认 5000"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(cfg.optLong("showMs", 5000L).toString())
        }
        content.addView(showTime)
        val fadeTime = EditText(this).apply {
            hint = "淡出时间（毫秒），默认 1000"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(cfg.optLong("fadeMs", 1000L).toString())
        }
        content.addView(fadeTime)
        content.addView(actionCard("保存设置", "只影响当前目标应用") {
            cfg.put("popupEnabled", popupSwitch.isChecked)
            cfg.put("popupText", edit.text.toString().ifBlank { "你好" })
            cfg.put("showMs", showTime.text.toString().toLongOrNull()?.coerceIn(500L, 60000L) ?: 5000L)
            cfg.put("fadeMs", fadeTime.text.toString().toLongOrNull()?.coerceIn(0L, 5000L) ?: 1000L)
            ConfigClient.save(contentResolver, selectedPackage, cfg)
            ConfigClient.log(contentResolver, selectedPackage, "设置已保存")
            Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show()
        })
        content.addView(actionCard("查看该应用日志", "独立保存，不与其他应用混合") { showLogs(selectedPackage, selectedName) })
    }

    private fun showLogsPicker() {
        val apps = loadLaunchableApps().filter { it.first != packageName }
        if (apps.isEmpty()) { showLogs(selectedPackage, selectedName); return }
        val labels = apps.map { "${it.second} (${it.first})" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("选择应用日志").setItems(labels) { _, which ->
            showLogs(apps[which].first, apps[which].second)
        }.setNegativeButton("取消", null).show()
    }

    private fun showLogs(pkg: String, name: String) {
        content.removeAllViews()
        content.addView(backRow("‹  返回") { if (pkg == selectedPackage) showAppSettings() else showHome() })
        content.addView(sectionTitle("$name · 实时日志"))
        val text = TextView(this).apply {
            setTextColor(ink); textSize = 12f; typeface = Typeface.MONOSPACE
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.WHITE, dp(12))
            val raw = ConfigClient.call(contentResolver, "get_logs", pkg).getString("logs") ?: ""
            this.text = raw.lines().asReversed().joinToString("\n")
                .ifBlank { "暂无日志。打开目标应用并触发模块功能后，记录会显示在这里。" }
        }
        content.addView(text, LinearLayout.LayoutParams(-1, -2))
        content.addView(actionCard("刷新日志", "重新读取当前记录") { showLogs(pkg, name) })
        content.addView(actionCard("清空日志", "只清空当前应用的日志") {
            ConfigClient.call(contentResolver, "clear_logs", pkg)
            ConfigClient.log(contentResolver, pkg, "日志已清空")
            showLogs(pkg, name)
        })
        content.addView(actionCard("每 2 秒刷新", "打开简易轮询日志视图") {
            AlertDialog.Builder(this).setMessage("当前版本提供手动刷新。返回本页点击“刷新日志”即可读取最新记录。")
                .setPositiveButton("知道了", null).show()
        })
    }

    private fun showHelp() {
        AlertDialog.Builder(this).setTitle("使用说明")
            .setMessage("1. 在 LSPosed 管理器安装并启用本模块。\n2. 打开模块作用域，勾选要作用的目标应用。\n3. 回到本模块首页，开启同一应用的开关。\n4. 点击应用卡片，配置弹窗内容并保存。\n\n作用域状态无法由普通模块界面可靠读取，所以开启时会提醒你确认。每个应用的配置与日志独立保存。")
            .setPositiveButton("明白", null).show()
    }

    private fun loadLaunchableApps(): List<Pair<String, String>> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return try {
            @Suppress("DEPRECATION")
            packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
                .mapNotNull {
                    val pkg = it.activityInfo?.packageName ?: return@mapNotNull null
                    val name = it.loadLabel(packageManager)?.toString() ?: pkg
                    pkg to name
                }.distinctBy { it.first }.sortedBy { it.second.lowercase(Locale.getDefault()) }
        } catch (_: Throwable) { emptyList() }
    }

    private fun getVersion(pkg: String): String = try {
        @Suppress("DEPRECATION")
        packageManager.getPackageInfo(pkg, 0).versionName ?: "未知"
    } catch (_: Throwable) { "未安装" }

    private fun sectionTitle(s: String) = label(s, 18, ink, true).apply {
        setPadding(dp(2), dp(12), dp(2), dp(10))
    }
    private fun label(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = rounded(Color.WHITE, dp(16))
        elevation = dp(2).toFloat()
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
    }
    private fun actionCard(title: String, subtitle: String, action: () -> Unit): View {
        val c = card()
        c.addView(label(title, 15, ink, true))
        c.addView(label(subtitle, 12, Color.GRAY, false).apply { setPadding(0, dp(5), 0, 0) })
        c.setOnClickListener { action() }
        return c
    }
    private fun backRow(s: String, action: () -> Unit) = label(s, 15, Color.rgb(76, 83, 210), true).apply {
        setPadding(dp(2), dp(10), dp(2), dp(12)); setOnClickListener { action() }
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
}
